/*
Name:K.Surya Kiran
Description:AddressBook Project
Date:23-09-2024
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
//#include "populate.h"
int mobile_validation(char *mobile_num);
int mail_validation(char *email);
void createContact(AddressBook *addressBook)
{
    char per_name[50];//temporarily creating variable for name
    printf("Enter the Name:\n");
    getchar();//waiting for a input from stdin 
again_again://label
    int ch=scanf("%[^\n]",per_name);//taking return value of scanf and taking input from user
   getchar(); 
    if(ch==0)//if user not enter any thing ask to write name again
    {
	printf("Please Enter the name:\n");
	goto again_again; 
    }
    char mobile_num[20];//craeting string for mobile number temporarily
    enter_again://label for mobile number
    printf("Enter mobile number:\n");
    scanf("%[^\n]",mobile_num);//asking values to return from user
    getchar();
    int valid_mobile=mobile_validation(mobile_num);//validating mobile
    if(valid_mobile!=0)//if mobile number is validated
    {
    int k;//craeting a variable
    for(k=0;k<=addressBook->contactCount;k++)
    {
	int ph=strcmp(addressBook->contacts[k].phone,mobile_num);//comparing mobile number with dummy contacts 
	if(ph==0)
	{
	    printf("This Contact is Allready saved,Please Enter 10 digit number (0-9):\n");//if contact is found
	    goto enter_again;
	}
    }
    }
    else
    {
//	getchar();
        printf("Enter 10 digit '0'-'9' mobile number:\n");
        goto enter_again;
    }
     //creating temporory variable for g_mail
    char temp_gmail[200];//creating a string for a temporary variable
    retry_email:
    printf("Enter the Email : ");
  //  getchar();
    scanf("%[^\n]",temp_gmail);//asking mail from user
    getchar();
    int valid_email=mail_validation(temp_gmail);//validating mail
    if(valid_email==0)
    {
      printf("Enter a valid mail with both @ &.com:");
      goto retry_email;
    }
    printf("Contact Added Successfully\n");
    //copying user entered name phone number and mail into addressBook
    strcpy(addressBook->contacts[addressBook->contactCount].name,per_name);
    strcpy(addressBook->contacts[addressBook->contactCount].phone,mobile_num);
    strcpy(addressBook->contacts[addressBook->contactCount].email,temp_gmail);
    addressBook->contactCount++;
}
void listContacts(AddressBook *addressBook) 
{
    int i;
    for(i=0;i<addressBook->contactCount;i++)//run untill count times 
    {
	printf("Name:%s",addressBook->contacts[i].name);
	printf("Phone:%s",addressBook->contacts[i].phone);
	printf("mail:%s",addressBook->contacts[i].email);
	printf("\n");
    }

}
void searchContact(AddressBook *addressBook) 
{
    char search;
    label:
    printf("1. Name\n");
    printf("2. Mobile number\n");
    printf("3. E-mail id\n");
    printf("What do you want to search:\n");
    getchar();
    scanf("%c",&search);//searching for 

    if(search>='1'&&search<='3')
    {
        if (search == '1')//To Search Name
        {
        char str2[20];//Creating string with name to search
	getchar();//buffer
        printf("Enter the name to search for: ");
        scanf("%[^\n]", str2);//asking name from user to search
	getchar();
        int found = 0;//for intimating contact is found or not
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].name, str2) == 0)//comparing 
            {
                printf("Name: %s\n", addressBook->contacts[i].name);
                printf("Phone: %s\n", addressBook->contacts[i].phone);
                printf("E-mail: %s\n", addressBook->contacts[i].email);
                found = 1;
		printf("Contact searched successfully througn name\n");
                break;
            }
        }
        if (found==0)//if contact not found
        {
            printf("No contact with the name exists in the address book.\n");
        }
      }
      else if (search == '2')//mobile_number
      {
        char str2[20];//craeting string to search for mobile number
        enter_again://label
        printf("Enter the mobile number to search for: ");
	getchar();//buffer
        scanf("%[^\n]", str2);//asking user to enter mobile number to search
	getchar();
        int validate_mobile=mobile_validation(str2);//validating user enter mobile number
        if(validate_mobile!=0)//if it is valid searching this for a phone number in addressBook
        {
        int found = 0;
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].phone,str2)==0) 
            {
                printf("Name: %s\n", addressBook->contacts[i].name);
                printf("Phone: %s\n", addressBook->contacts[i].phone);
                printf("E-mail: %s\n", addressBook->contacts[i].email);
                found = 1;
		printf("Contact searched successfully through mobile number\n");
                break;
            }
        }
        if (found==0)
        {
            printf("No contact with the mobile number exists in the address book.\n");
        }
        }
        else
        {
            printf("Enter 10 digit number from 0-9:");
            goto enter_again;
        }
     }

      else if (search == '3')//mail
      {
        char str2[30];//creating string for email
        re_enter:
        printf("Enter the e-mail to search for: ");
	getchar();//buffer
        scanf("%[^\n]", str2);//asking user to enter email
	getchar();
        int mail_validate=mail_validation(str2);
        if(mail_validate!=0)
        {
        int found = 0;
        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].email, str2) == 0)
            {
                printf("Name: %s\n", addressBook->contacts[i].name);
                printf("Phone: %s\n", addressBook->contacts[i].phone);
                printf("E-mail: %s\n", addressBook->contacts[i].email);
                found = 1;
		printf("Contact Searched Successfully through mail\n");
                break;
            }
        }
        if (!found)
        {
            printf("No contact with the e-mail exists in the address book.\n");
        }
        }
        else
        {
            printf("Please Enter Valid email with @ and .com");
            goto re_enter;
        }
    }
    }
    else
    {
        printf("Please Enter digits only betwnn 1 to 3:");
        goto label;
    }
}
void editContact(AddressBook *addressBook)
{
    int num;
    printf("1.Name:\n");
    printf("2.mail:\n");
    printf("3.phone:\n");
    printf("Enter which want you search:\n");
    scanf("%d",&num);//asking user to get edit name/mobile number/email
    getchar();
    if(num>=1&&num<=3)//if user enter value is between 1 to 3
    {
	if(num==1)
	{
	    char str[20];//craeting string for user to enter name into it
	    printf("Enter the name what you want to replace:");
	    scanf("%[^\n]",str);//asking from user to enter name 
	    int i;
        int found=0;
	    for(i=0;i<addressBook->contactCount;i++)
	    {
	       if(strcmp(addressBook->contacts[i].name,str)==0)
	       {
               char edit_name[20];
               printf("Enter the name you want to edit:");
	       getchar();
               scanf("%[^\n]",edit_name);//what to edit ask from user
               strcpy(addressBook->contacts[i].name,edit_name);//copying new name into AddressBook
	       printf("Name Updated Successfully\n"); 
               found=1;
               break;
           }
        }
        if(found==0)
        printf("User entered name is not found\n");
    }
    else if(num==2)
    {
        char str[20];//creating string for mail from user
        again:
	    printf("Enter the mail what you want to replace:");
	    scanf("%[^\n]",str);//asking mail from user
	    int i;
        int ret=mail_validation(str);//validating mail
        if(ret!=0)
        {
        int found=0;
	    for(i=0;i<addressBook->contactCount;i++)
	    {
	       if(strcmp(addressBook->contacts[i].email,str)==0)//comparing mail with the addressBook Contacts
	       {
              char mail[100];
               re_enter:
               printf("Enter the mail you want to edit:");
	       getchar();
               scanf("%[^\n]",mail);// ask new mail from user
               int ret33=mail_validation(mail);
               if(ret33!=0)
               {
                strcpy(addressBook->contacts[i].email,mail);//copying new mail into addressBook
		printf("Email Updated successfully\n");
               }
               found=1;
           }
        }
        if(found==0)
        printf("User entered mail is not found");
        }
        else
        {
            printf("Please Enter valid mail to search");
            goto again;
        }
    }
    else if(num==3)
    {
        char str[20];
        again1:
	    printf("Enter the mobile_number what you want to replace:");
	    scanf("%[^\n]",str);
	    int i;
        int ret=mobile_validation(str);
        if(ret!=0)
        {
        int found=0;
	    for(i=0;i<addressBook->contactCount;i++)
	    {
	       if(strcmp(addressBook->contacts[i].phone,str)==0)
	       {
              char mobile[20];
               re_enter1:
               printf("Enter the mail you want to edit:");
               scanf("%s",mobile);
               int squ=mail_validation(mobile);
               if(squ!=0)
               {
                strcpy(addressBook->contacts[i].phone,mobile);
                printf("Mobile Number updated Succesfully");
               }
               else
               {
                printf("Invalid mobile_number");
                   goto re_enter1;
               }
               found=1;
               break;
           }
        }
        if(found==0)
        printf("User entered mobile_number is not found");
        }
        else
        {
            printf("Please Enter valid mail to search");
            goto again1;
        }

    }
    }
}
void deleteContact(AddressBook *addressBook)//shifting unwanted contact deleting contact by referencing name phone number or mail
{
    printf("1.Name:\n");
    printf("2.mobile:\n");
    printf("3.mail:\n");
    printf("Enter which want you delete:\n");
    int numb;
    scanf("%d",&numb);
    getchar();
    int i,j;
    int found=0;
    if(numb>=1&&numb<=3)
    {
    if(numb==1)
    {
        char str4[15];
        printf("Enter the name:\n");
        scanf("%[^\n]",str4);
    for(i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].name,str4)==0)
        {
            for(j=i;j<addressBook->contactCount-1;j++)
            {
                addressBook->contacts[j]=addressBook->contacts[j+1];
            }
            addressBook->contactCount--;
            found=1;
	    printf("Contact Deleted Succesfully\n");
            break;
        }
    }
    if(found==0)
    printf("Contact not found");
    }
    if(numb==2)
    {
        char str4[20];
        printf("Enter the number:");
        scanf("%[^\n]",str4);
        int rett=mobile_validation(str4);
        if(rett!=0)
        {
        for(i=0;i<addressBook->contactCount;i++)
        {
          if(strcmp(addressBook->contacts[i].phone,str4)==0)
          {
          for(j=i;j<addressBook->contactCount-1;j++)
          {
            addressBook->contacts[j]=addressBook->contacts[j+1];
          }
          addressBook->contactCount--;
            found=1;
	    printf("Contact deleted successfully\n");
            break;
           }
        }
         if(found==0)
          printf("Contact not found");
      }
    else
    printf("Enter a 10 digit mobile number from 0-9");
    }
    if(numb==3)
    {
        char str4[50];
        printf("Enter the mail:");
        scanf("%[^\n]",str4);//asking user to enter mail
        int rett=mail_validation(str4);//validating mail
        if(rett!=0)
        {
        for(i=0;i<addressBook->contactCount;i++)
        {
          if(strcmp(addressBook->contacts[i].email,str4)==0)//comparing mobile number with addressBook cotacts
          {
          for(j=i;j<addressBook->contactCount-1;j++)
          {
            addressBook->contacts[j]=addressBook->contacts[j+1];
          }
          addressBook->contactCount--;
            found=1;
	    printf("Contact deleted successfully\n");
            break;
           }
        }
         if(found==0)
          printf("email not found");
        }
        else
        printf("Enter valid mail with @ & .com");
    }
    }
    else
    printf("Enter the number from 1 to upto 3");
}
void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0;
   // populateAddressBook(addressBook);
    loadContactsFromFile(addressBook);
}
void saveAndExit(AddressBook *addressBook)
{
   	exit(EXIT_SUCCESS);
}
int mobile_validation(char *mobile_num)//function for mobile number validation
{
   int i,x=0,flag=0;
   for(i=0;mobile_num[i]!='\0';i++)
   {
    if(mobile_num[i]>='0' && mobile_num[i]<='9')
    {
        x++;
    }
    else
    flag=1;
   } 
   if(flag==1)
   {
    printf("Please Enter only integers");
    return 0;
   }
   else
   {
      if(x!=10)
      return 0;
      else
      return 1;
   }  
}
int len(char *str)//function to find length of a string
{
    int i;
    for(i=0;str[i]!='\0';i++)
    {

    }
    return i;
}
int mail_validation(char *email)//function to find email from user
{
    if(email[0]=='@')//if mail starts with @ it is not valid
    return 0;
    char *ret1 = strchr(email, '@');//checking wether the mail has @ or not
    char *ret2 = strstr(email, ".com");//checking wether mail has .com extension or not
    char *ret3 =strstr(email,"@.com");//checking wether mail has @.com extension
    if (ret1 == NULL || ret2 == NULL|| ret3!=NULL)//checking all the conditions for mail
        return 0;
    if(*(ret2+4)!='\0')
        return 0;
    else
        return 1; // Valid email
}
